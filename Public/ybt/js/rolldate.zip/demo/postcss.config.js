module.exports = {
    plugins: [require('autoprefixer')({//补全前缀
    	browsers: ['last 20 versions']
    })]
}